from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app)

# ... (Database setup, user authentication, etc.) ...

@app.route('/vote/<poll_id>', methods=['POST'])
def vote(poll_id):
    # ... (Get selected option, store vote in database) ...
    results = get_poll_results(poll_id)  # Function to fetch updated results
    socketio.emit('update_results', results, room=poll_id) # Broadcast to all clients in the room
    return jsonify({'message': 'Vote recorded'})

@socketio.on('connect', namespace='/poll_updates')
def handle_connect(poll_id):
    # ... (Join the room for the specific poll) ...
    join_room(poll_id)

# ... (Other routes, etc.) ...

if __name__ == '__main__':
    socketio.run(app, debug=True)